#!/bin/bash
echo "Update in progress . . ."
sudo rm -f /usr/local/bin/olid
rm editor.cpp uninstall.sh
wget
tar xf olid.tar.gz
rm olid.tar.gz
cd olid
# Compile the C++ editor
g++ -o olid editor.cpp
mov olid /home
cd /home
sudo mv olid /usr/local/bin/olid

# Ensure it is executable
sudo chmod +x /usr/local/bin/olid
echo "Update finished"

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ncurses.h>

using namespace std;

// Function to load file into a vector of strings
vector<string> loadFile(const string& filename) {
    vector<string> lines;
    ifstream file(filename);
    if (!file.is_open()) {
        lines.push_back(""); // Start with an empty line if the file doesn't exist
    } else {
        string line;
        while (getline(file, line)) {
            lines.push_back(line);
        }
        file.close();
    }
    return lines;
}

// Function to save file from a vector of strings
void saveFile(const string& filename, const vector<string>& lines) {
    ofstream file(filename);
    if (!file.is_open()) {
        return;
    }
    for (const auto& line : lines) {
        file << line << endl;
    }
    file.close();
}

// Main text editor function
void nanoEditor(const string& filename) {
    vector<string> lines = loadFile(filename);
    int row = 0, col = 0;  // Cursor position

    initscr();            // Initialize ncurses
    noecho();             // Don't echo input
    raw();                // Disable line buffering
    keypad(stdscr, TRUE); // Enable arrow keys

    while (true) {
        clear(); // Clear screen before rendering
        for (size_t i = 0; i < lines.size(); ++i) {
            mvprintw(i, 0, "%s", lines[i].c_str()); // Print each line
        }
        move(row, col); // Move cursor to correct position
        refresh(); // Refresh screen

        int ch = getch(); // Get user input

        switch (ch) {
            case KEY_UP:
                if (row > 0) row--;
                if (col > lines[row].size()) col = lines[row].size();
                break;
            case KEY_DOWN:
                if (row < lines.size() - 1) row++;
                if (col > lines[row].size()) col = lines[row].size();
                break;
            case KEY_LEFT:
                if (col > 0) col--;
                else if (row > 0) { row--; col = lines[row].size(); }
                break;
            case KEY_RIGHT:
                if (col < lines[row].size()) col++;
                else if (row < lines.size() - 1) { row++; col = 0; }
                break;
            case KEY_BACKSPACE:
            case 127:
                if (col > 0) {
                    lines[row].erase(col - 1, 1);
                    col--;
                } else if (row > 0) {
                    col = lines[row - 1].size();
                    lines[row - 1] += lines[row];
                    lines.erase(lines.begin() + row);
                    row--;
                }
                break;
            case '\n': // Enter key
                lines.insert(lines.begin() + row + 1, lines[row].substr(col));
                lines[row] = lines[row].substr(0, col);
                row++;
                col = 0;
                break;
            case 27: // Escape key (exit)
                saveFile(filename, lines);
                endwin();
                return;
            default:
                lines[row].insert(col, 1, ch);
                col++;
                break;
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cout << "Usage: ./nano_clone <filename>" << endl;
        return 1;
    }
    string filename = argv[1];
    nanoEditor(filename);
    return 0;
}


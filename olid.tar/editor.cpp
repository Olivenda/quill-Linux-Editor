#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

// ANSI color codes for terminal output
const string RESET = "\033[0m";
const string RED = "\033[31m";
const string GREEN = "\033[32m";
const string YELLOW = "\033[33m";
const string BLUE = "\033[34m";
const string CYAN = "\033[36m";

// Function to display file content with colors
void displayFile(const vector<string>& lines) {
    system("clear");  // Use "cls" for Windows, or "clear" for Unix-based systems
    cout << CYAN << "=== File Content ===" << RESET << endl;
    for (size_t i = 0; i < lines.size(); ++i) {
        cout << YELLOW << i + 1 << ": " << RESET << lines[i] << endl;
    }
    cout << endl;
}

// Function to edit a file's content
void editFile(vector<string>& lines) {
    string input;
    int lineNumber;
    while (true) {
        displayFile(lines);
        cout << BLUE << "Enter line number to edit (or 0 to save and exit): " << RESET;
        cin >> lineNumber;
        cin.ignore();
        
        if (lineNumber == 0) {
            break;  // Exit and save
        }
        if (lineNumber > 0 && lineNumber <= lines.size()) {
            cout << GREEN << "New text for line " << lineNumber << ": " << RESET;
            getline(cin, lines[lineNumber - 1]);  // Edit the selected line
        } else if (lineNumber == lines.size() + 1) {
            // Adding a new line
            cout << GREEN << "Enter new line: " << RESET;
            getline(cin, input);
            lines.push_back(input);  // Add a new line at the end
        } else {
            cout << RED << "Invalid line number, try again." << RESET << endl;
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cout << RED << "Usage: ./editor <filename>" << RESET << endl;
        return 1;
    }
    
    string filename = argv[1];
    vector<string> lines;
    string line;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << RED << "Failed to open file: " << filename << RESET << endl;
        return 1;
    }
    while (getline(file, line)) {
        lines.push_back(line);
    }
    file.close();
    
    editFile(lines);

    ofstream outFile(filename);
    if (!outFile.is_open()) {
        cout << RED << "Failed to save file: " << filename << RESET << endl;
        return 1;
    }
    for (const auto& l : lines) {
        outFile << l << endl;
    }
    outFile.close();
    
    cout << GREEN << "File saved successfully!" << RESET << endl;
    return 0;
}


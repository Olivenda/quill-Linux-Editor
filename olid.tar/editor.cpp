#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

void displayFile(const vector<string>& lines) {
    system("clear");
    for (size_t i = 0; i < lines.size(); ++i) {
        cout << i + 1 << ": " << lines[i] << endl;
    }
}

void editFile(vector<string>& lines) {
    string input;
    int lineNumber;
    while (true) {
        displayFile(lines);
        cout << "Enter line number to edit (or 0 to save and exit): ";
        cin >> lineNumber;
        cin.ignore();
        if (lineNumber == 0) break;
        if (lineNumber > 0 && lineNumber <= lines.size()) {
            cout << "New text: ";
            getline(cin, lines[lineNumber - 1]);
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cout << "Usage: ./editor <filename>" << endl;
        return 1;
    }
    
    string filename = argv[1];
    vector<string> lines;
    string line;
    
    ifstream file(filename);
    while (getline(file, line)) {
        lines.push_back(line);
    }
    file.close();
    
    editFile(lines);

    ofstream outFile(filename);
    for (const auto& l : lines) {
        outFile << l << endl;
    }
    outFile.close();
    
    cout << "File saved successfully!" << endl;
    return 0;
}

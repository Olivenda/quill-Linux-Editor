#!/bin/bash

# Remove the editor binary from /usr/local/bin
sudo rm -f /usr/local/bin/olid

echo "Uninstallation complete! The editor has been removed."

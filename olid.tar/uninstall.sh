#!/bin/bash

# Remove the editor binary from /usr/local/bin
sudo rm -f /usr/local/bin/olid 
rm editor.cpp
rm update.sh

echo "Uninstallation complete! The editor has been removed."
sleep 2
rm uninstall.sh

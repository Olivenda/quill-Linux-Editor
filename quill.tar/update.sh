#!/usr/bin/env bash
# safer, idempotent updater for quill
# Usage: ./update.sh
set -euo pipefail
IFS=$'\n\t'

REPO_TAR_URL="https://github.com/Olivenda/quill-Linux-Editor/archive/refs/heads/main.tar.gz"
TMPDIR="$(mktemp -d)"
OLD_BINARY="/usr/local/bin/quill"
BACKUP_SUFFIX="$(date +%s)"

cleanup() {
    rm -rf "$TMPDIR"
}
trap cleanup EXIT

echo "Updating Quill in $TMPDIR ..."

cd "$TMPDIR"

# Download with progress, fail on network error
if ! wget --no-verbose --show-progress --timeout=30 --tries=3 "$REPO_TAR_URL" -O olid.tar; then
    echo "Download failed" >&2
    exit 2
fi

# Extract into temp dir
tar -xvf olid.tar

# Expect editor.cpp or a compiled binary named `olid` or similar.
if [[ -f editor.cpp ]]; then
    echo "Compiling editor.cpp..."
    # compile with useful flags; adjust std as needed
    g++ -std=c++17 -O2 -Wall -Wextra -pedantic -o quill editor.cpp
elif [[ -f olid ]]; then
    echo "Found prebuilt 'olid' binary, installing as quill..."
    mv olid quill
else
    echo "No editor.cpp or prebuilt binary found in archive" >&2
    exit 3
fi

# Make executable
chmod +x quill

# Backup existing binary if present
if [[ -f "$OLD_BINARY" ]]; then
    echo "Backing up existing $OLD_BINARY -> ${OLD_BINARY}.bak.$BACKUP_SUFFIX"
    sudo cp -a "$OLD_BINARY" "${OLD_BINARY}.bak.$BACKUP_SUFFIX"
fi

# Install atomically
echo "Installing to /usr/local/bin/quill (requires sudo)..."
sudo install -m 0755 quill /usr/local/bin/quill

echo "Update finished. Installed /usr/local/bin/quill"
